import { Client, Databases } from "node-appwrite";

const DB_ID = process.env.DATABASE_ID;
const FLIGHTS_COL_ID = process.env.FLIGHTS_COL_ID;

/** Parse CSV-encoded FlightRecordMeta to extract materialized fields (minimal). */
function extractMaterializedFields(csvText) {
  if (!csvText?.trim()) return {};
  try {
    // Look for the JSON meta block: lines starting with #meta:
    const lines = csvText.split("\n");
    const metaLine = lines.find((l) => l.startsWith("#meta:"));
    if (!metaLine) return {};
    const meta = JSON.parse(metaLine.slice(6));
    const legs = meta.legs ?? [];
    if (!legs.length) return {};

    const firstLeg = legs[0];
    const lastLeg = legs[legs.length - 1];
    const dep = firstLeg?.dep ?? "";
    const arr = lastLeg?.arr ?? "";
    const fromTo = dep && arr ? (dep === arr ? dep : `${dep} → ${arr}`) : "";
    const landings = legs.reduce((s, l) => s + (Number(l.landings) || 0), 0);

    // Parse HH:MM time strings to minutes
    function toMinutes(hhmm) {
      if (!hhmm) return 0;
      const [h, m] = String(hhmm).split(":").map(Number);
      return (h || 0) * 60 + (m || 0);
    }
    const totalFlightMinutes = legs.reduce((s, l) => s + toMinutes(l.flightTime), 0);
    const blockMinutes = legs.reduce((s, l) => s + toMinutes(l.serviceTime || l.flightTime), 0);

    const flightDate = meta.header?.date ?? null;
    const startTime = meta.header?.startTime ?? null;

    return {
      from_to: fromTo || null,
      landings: landings || null,
      total_flight_minutes: totalFlightMinutes || null,
      block_time_minutes: blockMinutes || null,
      ...(flightDate ? { flight_date: flightDate } : {}),
      ...(startTime ? { start_time: startTime } : {}),
    };
  } catch {
    return {};
  }
}

export default async ({ req, res, log, error }) => {
  const client = new Client()
    .setEndpoint(process.env.APPWRITE_FUNCTION_API_ENDPOINT)
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
    .setKey(process.env.APPWRITE_API_KEY);

  const databases = new Databases(client);

  if (!DB_ID || !FLIGHTS_COL_ID) {
    return res.json({ ok: false, message: "Function not configured (DATABASE_ID or FLIGHTS_COL_ID missing)." }, 500);
  }

  try {
    const body = JSON.parse(req.body || "{}");
    const {
      action,
      flightId,
      csvText,
      flightStatus,
      trainingTrackId,
      trainingStageId,
      trainingMissionId,
      trainingSnapshotJson,
    } = body;

    if (action !== "patchFlightAsInstructor") {
      return res.json({ ok: false, message: "Unknown action." }, 400);
    }

    if (!flightId) {
      return res.json({ ok: false, message: "flightId required." }, 400);
    }

    // Caller identity — Appwrite sets this header when called from a browser session
    const callerUserId = req.headers["x-appwrite-user-id"];
    if (!callerUserId) {
      return res.json({ ok: false, message: "Não autenticado." }, 401);
    }

    // Fetch existing flight
    const flight = await databases.getDocument(DB_ID, FLIGHTS_COL_ID, flightId);

    // Verify caller is the assigned instructor
    if (flight.instructor_user_id !== callerUserId) {
      return res.json({ ok: false, message: "Apenas o instrutor atribuído pode preencher esta ficha." }, 403);
    }

    // Verify not locked
    if (flight.instructor_signed) {
      return res.json({ ok: false, message: "Ficha bloqueada — já assinada pelo instrutor." }, 403);
    }

    // Build update payload
    const materialized = csvText ? extractMaterializedFields(csvText) : {};

    const updateData = {
      ...(csvText !== undefined ? { csv_text: csvText, csv_file_id: null } : {}),
      ...(flightStatus !== undefined ? { flight_status: flightStatus } : {}),
      ...(trainingTrackId !== undefined ? { training_track_id: trainingTrackId } : {}),
      ...(trainingStageId !== undefined ? { training_stage_id: trainingStageId } : {}),
      ...(trainingMissionId !== undefined ? { training_mission_id: trainingMissionId } : {}),
      ...(trainingSnapshotJson !== undefined ? { training_snapshot_json: trainingSnapshotJson } : {}),
      ...materialized,
    };

    if (!Object.keys(updateData).length) {
      return res.json({ ok: false, message: "Nenhum campo para atualizar." }, 400);
    }

    await databases.updateDocument(DB_ID, FLIGHTS_COL_ID, flightId, updateData);

    log(`instructorPatchFlight: updated ${flightId} by instructor ${callerUserId}`);
    return res.json({ ok: true });
  } catch (err) {
    error(err.message);
    return res.json({ ok: false, message: err.message }, 500);
  }
};
